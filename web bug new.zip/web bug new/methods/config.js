module.exports = {
  Token: "7351385206:AAHpxfi1qbn5pUjJIcJFOzr4vSpsNps8O5A",
  owner: "7466190629",
};