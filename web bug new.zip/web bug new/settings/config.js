module.exports = {
  Token: "815526074",
  owner: "7466190629",
};